package ufrn.com.trabalho.Persistencia;

public class CarrinhoDAO {
    
}
