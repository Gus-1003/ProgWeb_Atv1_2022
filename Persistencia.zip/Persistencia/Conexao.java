package ufrn.com.trabalho.Persistencia;

public class Conexao {
    
}
