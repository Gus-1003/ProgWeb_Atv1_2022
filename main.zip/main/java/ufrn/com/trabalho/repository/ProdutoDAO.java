package ufrn.com.trabalho.repository;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ufrn.com.trabalho.model.Produto;

public class ProdutoDAO {

    public List<Produto> listarProdutos() {

        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Produto> listaDeProdutos = new ArrayList<>();

        try {
            connection = Conexao.getConnection();
            stmt = connection.prepareStatement("select * from produto");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Produto p = new Produto();

                p.setId(rs.getInt("id"));

                p.setNome(rs.getString("nome"));
                p.setMarca(rs.getString("marca"));
                p.setPesagem(rs.getString("pesagem"));
                p.setPreco(rs.getFloat("preco"));

                listaDeProdutos.add(p);

            }

            connection.close();

        } catch (SQLException | URISyntaxException ignored) {
        }

        return listaDeProdutos;
    }

    public List<Produto> listarProdutosPorId(int id) {

        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Produto> listaDeProdutos = new ArrayList<>();

        try {

            connection = Conexao.getConnection();
            stmt = connection.prepareStatement("select * from produto where id=?");
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {

                Produto p = new Produto();

                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setMarca(rs.getString("marca"));
                p.setPesagem(rs.getString("pesagem"));
                p.setPreco(rs.getFloat("preco"));
                listaDeProdutos.add(p);

            }

            connection.close();

        } catch (SQLException | URISyntaxException ignored) {
        }

        return listaDeProdutos;
    }

    public void cadastrarProduto(Produto p) {
        Connection connection = null;
        PreparedStatement stmt = null;

        try {
            connection = Conexao.getConnection();

            stmt = connection.prepareStatement(
                    "insert into produto (nome, marca, pesagem, preco) values (?,?,?,?)");

            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getMarca());
            stmt.setString(3, p.getPesagem());
            stmt.setFloat(4, p.getPreco());
            stmt.executeUpdate();
            connection.close();

        } catch (SQLException | URISyntaxException ex) {
            // response.getWriter().append("Connection Failed! Check output console");
        }
    }
}