package ufrn.com.trabalho.repository;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ufrn.com.trabalho.model.Usuario;

public class UsuarioDAO {

    public List<Usuario> listarUsuarios() {

        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Usuario> usuarios = new ArrayList<>();

        try {
            connection = Conexao.getConnection();
            stmt = connection.prepareStatement("select * from usuario");
            rs = stmt.executeQuery();

            while (rs.next()) {
                Usuario u = new Usuario();

                u.setId(rs.getInt("id"));
                u.setNome(rs.getString("nome"));
                u.setSenha(rs.getString("senha"));
                u.setCargo(rs.getInt("cargo"));
                usuarios.add(u);
            }

            connection.close();

        } catch (SQLException | URISyntaxException ignored) {
        }

        return usuarios;
    }

    public List<Usuario> listarUsuariosPorId(int id) {

        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Usuario> usuarios = new ArrayList<>();

        try {

            connection = Conexao.getConnection();
            stmt = connection.prepareStatement("select * from usuario where id=?");
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {

                Usuario u = new Usuario();

                u.setId(rs.getInt("id"));

                u.setNome(rs.getString("nome"));
                u.setSenha(rs.getString("senha"));
                u.setCargo(rs.getInt("cargo"));

                usuarios.add(u);
            }

            connection.close();

        } catch (SQLException | URISyntaxException ignored) {
        }

        return usuarios;
    }

    public void cadastrarUsuario(Usuario u) {
        Connection connection = null;
        PreparedStatement stmt = null;

        try {
            connection = Conexao.getConnection();

            stmt = connection.prepareStatement(
                    "insert into usuario (nome, senha, cargo) values (?,?,?)");

            stmt.setString(1, u.getNome());
            stmt.setString(2, u.getSenha());
            stmt.setInt(3, u.getCargo());

            stmt.executeUpdate();

            connection.close();

        } catch (SQLException | URISyntaxException ex) {
            // response.getWriter().append("Connection Failed! Check output console");
        }

    }

}
