package ufrn.com.trabalho.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Carrinho")
public class CarrinhoController {

}

// Visualizar Carrinho
// --------------------------------------

// Stringtokenizer - Id´s dos produtos passados por cokies

// --------------------------------------
